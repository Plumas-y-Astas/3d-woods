/*
    Copyright (c) 2005-2021 Intel Corporation

    Licensed under the Apache License, Version 2.0 (the "License");
    you may not use this file except in compliance with the License.
    You may obtain a copy of the License at

        http://www.apache.org/licenses/LICENSE-2.0

    Unless required by applicable law or agreed to in writing, software
    distributed under the License is distributed on an "AS IS" BASIS,
    WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
    See the License for the specific language governing permissions and
    limitations under the License.
*/

/*-------------------------------------------------------------*/
/*--- Decompression machinery                               ---*/
/*---                                        decompress.cpp ---*/
/*-------------------------------------------------------------*/

/* ------------------------------------------------------------------
   The original source for this example:
   This file is part of bzip2/libbzip2, a program and library for
   lossless, block-sorting data compression.

   bzip2/libbzip2 version 1.0.6 of 6 September 2010
   Copyright (C) 1996-2010 Julian Seward <jseward@bzip.org>

   This program, "bzip2", the associated library "libbzip2", and all
   documentation, are copyright (C) 1996-2010 Julian R Seward.  All
   rights reserved.

   Redistribution and use in source and binary forms, with or without
   modification, are permitted provided that the following conditions
   are met:

   1. Redistributions of source code must retain the above copyright
   notice, this list of conditions and the following disclaimer.

   2. The origin of this software must not be misrepresented; you must 
   not claim that you wrote the original software.  If you use this 
   software in a product, an acknowledgment in the product 
   documentation would be appreciated but is not required.

   3. Altered source versions must be plainly marked as such, and must
   not be misrepresented as being the original software.

   4. The name of the author may not be used to endorse or promote 
   products derived from this software without specific prior written 
   permission.

   THIS SOFTWARE IS PROVIDED BY THE AUTHOR ``AS IS'' AND ANY EXPRESS
   OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE IMPLIED
   WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
   ARE DISCLAIMED.  IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY
   DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
   DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE
   GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS
   INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
   WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING
   NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS
   SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.

   Julian Seward, jseward@bzip.org
   bzip2/libbzip2 version 1.0.6 of 6 September 2010
   ------------------------------------------------------------------ */

#include "bzlib_private.hpp"

/*---------------------------------------------------*/
static void makeMaps_d(DState* s) {
    Int32 i;
    s->nInUse = 0;
    for (i = 0; i < 256; i++)
        if (s->inUse[i]) {
            s->seqToUnseq[s->nInUse] = i;
            s->nInUse++;
        }
}

/*---------------------------------------------------*/
#define RETURN(rrr)                 \
    {                               \
        retVal = rrr;               \
        goto save_state_and_return; \
    };

#define GET_BITS(lll, vvv, nnn)                                                       \
    case lll:                                                                         \
        s->state = lll;                                                               \
        while (True) {                                                                \
            if (s->bsLive >= nnn) {                                                   \
                UInt32 v;                                                             \
                v = (s->bsBuff >> (s->bsLive - nnn)) & ((1 << nnn) - 1);              \
                s->bsLive -= nnn;                                                     \
                vvv = v;                                                              \
                break;                                                                \
            }                                                                         \
            if (s->strm->avail_in == 0)                                               \
                RETURN(BZ_OK);                                                        \
            s->bsBuff = (s->bsBuff << 8) | ((UInt32)(*((UChar*)(s->strm->next_in)))); \
            s->bsLive += 8;                                                           \
            s->strm->next_in++;                                                       \
            s->strm->avail_in--;                                                      \
            s->strm->total_in_lo32++;                                                 \
            if (s->strm->total_in_lo32 == 0)                                          \
                s->strm->total_in_hi32++;                                             \
        }

#define GET_UCHAR(lll, uuu) GET_BITS(lll, uuu, 8)

#define GET_BIT(lll, uuu) GET_BITS(lll, uuu, 1)

/*---------------------------------------------------*/
#define GET_MTF_VAL(label1, label2, lval)                                  \
    {                                                                      \
        if (groupPos == 0) {                                               \
            groupNo++;                                                     \
            if (groupNo >= nSelectors)                                     \
                RETURN(BZ_DATA_ERROR);                                     \
            groupPos = BZ_G_SIZE;                                          \
            gSel = s->selector[groupNo];                                   \
            gMinlen = s->minLens[gSel];                                    \
            gLimit = &(s->limit[gSel][0]);                                 \
            gPerm = &(s->perm[gSel][0]);                                   \
            gBase = &(s->base[gSel][0]);                                   \
        }                                                                  \
        groupPos--;                                                        \
        zn = gMinlen;                                                      \
        GET_BITS(label1, zvec, zn);                                        \
        while (1) {                                                        \
            if (zn > 20 /* the longest code */)                            \
                RETURN(BZ_DATA_ERROR);                                     \
            if (zvec <= gLimit[zn])                                        \
                break;                                                     \
            zn++;                                                          \
            GET_BIT(label2, zj);                                           \
            zvec = (zvec << 1) | zj;                                       \
        };                                                                 \
        if (zvec - gBase[zn] < 0 || zvec - gBase[zn] >= BZ_MAX_ALPHA_SIZE) \
            RETURN(BZ_DATA_ERROR);                                         \
        lval = gPerm[zvec - gBase[zn]];                                    \
    }

/*---------------------------------------------------*/
Int32 BZ2_decompress(DState* s) {
    UChar uc;
    Int32 retVal;
    Int32 minLen, maxLen;
    bz_stream* strm = s->strm;

    /* stuff that needs to be saved/restored */
    Int32 i;
    Int32 j;
    Int32 t;
    Int32 alphaSize;
    Int32 nGroups;
    Int32 nSelectors;
    Int32 EOB;
    Int32 groupNo;
    Int32 groupPos;
    Int32 nextSym;
    Int32 nblockMAX;
    Int32 nblock;
    Int32 es;
    Int32 N;
    Int32 curr;
    Int32 zt;
    Int32 zn;
    Int32 zvec;
    Int32 zj;
    Int32 gSel;
    Int32 gMinlen;
    Int32* gLimit;
    Int32* gBase;
    Int32* gPerm;

    if (s->state == BZ_X_MAGIC_1) {
        /*initialise the save area*/
        s->save_i = 0;
        s->save_j = 0;
        s->save_t = 0;
        s->save_alphaSize = 0;
        s->save_nGroups = 0;
        s->save_nSelectors = 0;
        s->save_EOB = 0;
        s->save_groupNo = 0;
        s->save_groupPos = 0;
        s->save_nextSym = 0;
        s->save_nblockMAX = 0;
        s->save_nblock = 0;
        s->save_es = 0;
        s->save_N = 0;
        s->save_curr = 0;
        s->save_zt = 0;
        s->save_zn = 0;
        s->save_zvec = 0;
        s->save_zj = 0;
        s->save_gSel = 0;
        s->save_gMinlen = 0;
        s->save_gLimit = nullptr;
        s->save_gBase = nullptr;
        s->save_gPerm = nullptr;
    }

    /*restore from the save area*/
    i = s->save_i;
    j = s->save_j;
    t = s->save_t;
    alphaSize = s->save_alphaSize;
    nGroups = s->save_nGroups;
    nSelectors = s->save_nSelectors;
    EOB = s->save_EOB;
    groupNo = s->save_groupNo;
    groupPos = s->save_groupPos;
    nextSym = s->save_nextSym;
    nblockMAX = s->save_nblockMAX;
    nblock = s->save_nblock;
    es = s->save_es;
    N = s->save_N;
    curr = s->save_curr;
    zt = s->save_zt;
    zn = s->save_zn;
    zvec = s->save_zvec;
    zj = s->save_zj;
    gSel = s->save_gSel;
    gMinlen = s->save_gMinlen;
    gLimit = s->save_gLimit;
    gBase = s->save_gBase;
    gPerm = s->save_gPerm;

    retVal = BZ_OK;

    switch (s->state) {
        GET_UCHAR(BZ_X_MAGIC_1, uc);
        if (uc != BZ_HDR_B)
            RETURN(BZ_DATA_ERROR_MAGIC);

        GET_UCHAR(BZ_X_MAGIC_2, uc);
        if (uc != BZ_HDR_Z)
            RETURN(BZ_DATA_ERROR_MAGIC);

        GET_UCHAR(BZ_X_MAGIC_3, uc)
        if (uc != BZ_HDR_h)
            RETURN(BZ_DATA_ERROR_MAGIC);

        GET_BITS(BZ_X_MAGIC_4, s->blockSize100k, 8)
        if (s->blockSize100k < (BZ_HDR_0 + 1) || s->blockSize100k > (BZ_HDR_0 + 9))
            RETURN(BZ_DATA_ERROR_MAGIC);
        s->blockSize100k -= BZ_HDR_0;

        if (s->smallDecompress) {
            s->ll16 = (UInt16*)BZALLOC(s->blockSize100k * 100000 * sizeof(UInt16));
            s->ll4 = (UChar*)BZALLOC(((1 + s->blockSize100k * 100000) >> 1) * sizeof(UChar));
            if (s->ll16 == nullptr || s->ll4 == nullptr)
                RETURN(BZ_MEM_ERROR);
        }
        else {
            s->tt = (UInt32*)BZALLOC(s->blockSize100k * 100000 * sizeof(Int32));
            if (s->tt == nullptr)
                RETURN(BZ_MEM_ERROR);
        }

        GET_UCHAR(BZ_X_BLKHDR_1, uc);

        if (uc == 0x17)
            goto endhdr_2;
        if (uc != 0x31)
            RETURN(BZ_DATA_ERROR);
        GET_UCHAR(BZ_X_BLKHDR_2, uc);
        if (uc != 0x41)
            RETURN(BZ_DATA_ERROR);
        GET_UCHAR(BZ_X_BLKHDR_3, uc);
        if (uc != 0x59)
            RETURN(BZ_DATA_ERROR);
        GET_UCHAR(BZ_X_BLKHDR_4, uc);
        if (uc != 0x26)
            RETURN(BZ_DATA_ERROR);
        GET_UCHAR(BZ_X_BLKHDR_5, uc);
        if (uc != 0x53)
            RETURN(BZ_DATA_ERROR);
        GET_UCHAR(BZ_X_BLKHDR_6, uc);
        if (uc != 0x59)
            RETURN(BZ_DATA_ERROR);

        s->currBlockNo++;
        if (s->verbosity >= 2)
            VPrintf1("\n    [%d: huff+mtf ", s->currBlockNo);

        s->storedBlockCRC = 0;
        GET_UCHAR(BZ_X_BCRC_1, uc);
        s->storedBlockCRC = (s->storedBlockCRC << 8) | ((UInt32)uc);
        GET_UCHAR(BZ_X_BCRC_2, uc);
        s->storedBlockCRC = (s->storedBlockCRC << 8) | ((UInt32)uc);
        GET_UCHAR(BZ_X_BCRC_3, uc);
        s->storedBlockCRC = (s->storedBlockCRC << 8) | ((UInt32)uc);
        GET_UCHAR(BZ_X_BCRC_4, uc);
        s->storedBlockCRC = (s->storedBlockCRC << 8) | ((UInt32)uc);

        GET_BITS(BZ_X_RANDBIT, s->blockRandomised, 1);

        s->origPtr = 0;
        GET_UCHAR(BZ_X_ORIGPTR_1, uc);
        s->origPtr = (s->origPtr << 8) | ((Int32)uc);
        GET_UCHAR(BZ_X_ORIGPTR_2, uc);
        s->origPtr = (s->origPtr << 8) | ((Int32)uc);
        GET_UCHAR(BZ_X_ORIGPTR_3, uc);
        s->origPtr = (s->origPtr << 8) | ((Int32)uc);

        if (s->origPtr < 0)
            RETURN(BZ_DATA_ERROR);
        if (s->origPtr > 10 + 100000 * s->blockSize100k)
            RETURN(BZ_DATA_ERROR);

        /*--- Receive the mapping table ---*/
        for (i = 0; i < 16; i++) {
            GET_BIT(BZ_X_MAPPING_1, uc);
            if (uc == 1)
                s->inUse16[i] = True;
            else
                s->inUse16[i] = False;
        }

        for (i = 0; i < 256; i++)
            s->inUse[i] = False;

        for (i = 0; i < 16; i++)
            if (s->inUse16[i])
                for (j = 0; j < 16; j++) {
                    GET_BIT(BZ_X_MAPPING_2, uc);
                    if (uc == 1)
                        s->inUse[i * 16 + j] = True;
                }
        makeMaps_d(s);
        if (s->nInUse == 0)
            RETURN(BZ_DATA_ERROR);
        alphaSize = s->nInUse + 2;

        /*--- Now the selectors ---*/
        GET_BITS(BZ_X_SELECTOR_1, nGroups, 3);
        if (nGroups < 2 || nGroups > 6)
            RETURN(BZ_DATA_ERROR);
        GET_BITS(BZ_X_SELECTOR_2, nSelectors, 15);
        if (nSelectors < 1)
            RETURN(BZ_DATA_ERROR);
        for (i = 0; i < nSelectors; i++) {
            j = 0;
            while (True) {
                GET_BIT(BZ_X_SELECTOR_3, uc);
                if (uc == 0)
                    break;
                j++;
                if (j >= nGroups)
                    RETURN(BZ_DATA_ERROR);
            }
            s->selectorMtf[i] = j;
        }

        /*--- Undo the MTF values for the selectors. ---*/
        {
            UChar pos[BZ_N_GROUPS], tmp, v;
            for (i = 0; i < nGroups; i++)
                pos[i] = i;

            for (i = 0; i < nSelectors; i++) {
                v = s->selectorMtf[i];
                tmp = pos[v];
                while (v > 0) {
                    pos[v] = pos[v - 1];
                    v--;
                }
                pos[0] = tmp;
                s->selector[i] = tmp;
            }
        }

        /*--- Now the coding tables ---*/
        for (j = 0; j < nGroups; j++) {
            GET_BITS(BZ_X_CODING_1, curr, 5);
            for (i = 0; i < alphaSize; i++) {
                while (True) {
                    if (curr < 1 || curr > 20)
                        RETURN(BZ_DATA_ERROR);
                    GET_BIT(BZ_X_CODING_2, uc);
                    if (uc == 0)
                        break;
                    GET_BIT(BZ_X_CODING_3, uc);
                    if (uc == 0)
                        curr++;
                    else
                        curr--;
                }
                s->len[j][i] = curr;
            }
        }

        /*--- Create the Huffman decoding tables ---*/
        for (j = 0; j < nGroups; j++) {
            minLen = 32;
            maxLen = 0;
            for (i = 0; i < alphaSize; i++) {
                if (s->len[j][i] > maxLen)
                    maxLen = s->len[j][i];
                if (s->len[j][i] < minLen)
                    minLen = s->len[j][i];
            }
            BZ2_hbCreateDecodeTables(&(s->limit[j][0]),
                                     &(s->base[j][0]),
                                     &(s->perm[j][0]),
                                     &(s->len[j][0]),
                                     minLen,
                                     maxLen,
                                     alphaSize);
            s->minLens[j] = minLen;
        }

        /*--- Now the MTF values ---*/

        EOB = s->nInUse + 1;
        nblockMAX = 100000 * s->blockSize100k;
        groupNo = -1;
        groupPos = 0;

        for (i = 0; i <= 255; i++)
            s->unzftab[i] = 0;

        /*-- MTF init --*/
        {
            Int32 l, j, k;
            k = MTFA_SIZE - 1;
            for (l = 256 / MTFL_SIZE - 1; l >= 0; l--) {
                for (j = MTFL_SIZE - 1; j >= 0; j--) {
                    s->mtfa[k] = (UChar)(l * MTFL_SIZE + j);
                    k--;
                }
                s->mtfbase[l] = k + 1;
            }
        }
        /*-- end MTF init --*/

        nblock = 0;
        GET_MTF_VAL(BZ_X_MTF_1, BZ_X_MTF_2, nextSym);

        while (True) {
            if (nextSym == EOB)
                break;

            if (nextSym == BZ_RUNA || nextSym == BZ_RUNB) {
                es = -1;
                N = 1;
                do {
                    /* Check that N doesn't get too big, so that es doesn't
                  go negative.  The maximum value that can be
                  RUNA/RUNB encoded is equal to the block size (post
                  the initial RLE), viz, 900k, so bounding N at 2
                  million should guard against overflow without
                  rejecting any legitimate inputs. */
                    if (N >= 2 * 1024 * 1024)
                        RETURN(BZ_DATA_ERROR);
                    if (nextSym == BZ_RUNA)
                        es = es + (0 + 1) * N;
                    else if (nextSym == BZ_RUNB)
                        es = es + (1 + 1) * N;
                    N = N * 2;
                    GET_MTF_VAL(BZ_X_MTF_3, BZ_X_MTF_4, nextSym);
                } while (nextSym == BZ_RUNA || nextSym == BZ_RUNB);

                es++;
                uc = s->seqToUnseq[s->mtfa[s->mtfbase[0]]];
                s->unzftab[uc] += es;

                if (s->smallDecompress)
                    while (es > 0) {
                        if (nblock >= nblockMAX)
                            RETURN(BZ_DATA_ERROR);
                        s->ll16[nblock] = (UInt16)uc;
                        nblock++;
                        es--;
                    }
                else
                    while (es > 0) {
                        if (nblock >= nblockMAX)
                            RETURN(BZ_DATA_ERROR);
                        s->tt[nblock] = (UInt32)uc;
                        nblock++;
                        es--;
                    };

                continue;
            }
            else {
                if (nblock >= nblockMAX)
                    RETURN(BZ_DATA_ERROR);

                /*-- uc = MTF ( nextSym-1 ) --*/
                {
                    Int32 i, j, k, l, lno, off;
                    UInt32 nn;
                    nn = (UInt32)(nextSym - 1);

                    if (nn < MTFL_SIZE) {
                        /* avoid general-case expense */
                        l = s->mtfbase[0];
                        uc = s->mtfa[l + nn];
                        while (nn > 3) {
                            Int32 z = l + nn;
                            s->mtfa[(z)] = s->mtfa[(z)-1];
                            s->mtfa[(z)-1] = s->mtfa[(z)-2];
                            s->mtfa[(z)-2] = s->mtfa[(z)-3];
                            s->mtfa[(z)-3] = s->mtfa[(z)-4];
                            nn -= 4;
                        }
                        while (nn > 0) {
                            s->mtfa[(l + nn)] = s->mtfa[(l + nn) - 1];
                            nn--;
                        };
                        s->mtfa[l] = uc;
                    }
                    else {
                        /* general case */
                        lno = nn / MTFL_SIZE;
                        off = nn % MTFL_SIZE;
                        l = s->mtfbase[lno] + off;
                        uc = s->mtfa[l];
                        while (l > s->mtfbase[lno]) {
                            s->mtfa[l] = s->mtfa[l - 1];
                            l--;
                        };
                        s->mtfbase[lno]++;
                        while (lno > 0) {
                            s->mtfbase[lno]--;
                            s->mtfa[s->mtfbase[lno]] = s->mtfa[s->mtfbase[lno - 1] + MTFL_SIZE - 1];
                            lno--;
                        }
                        s->mtfbase[0]--;
                        s->mtfa[s->mtfbase[0]] = uc;
                        if (s->mtfbase[0] == 0) {
                            k = MTFA_SIZE - 1;
                            for (i = 256 / MTFL_SIZE - 1; i >= 0; i--) {
                                for (j = MTFL_SIZE - 1; j >= 0; j--) {
                                    s->mtfa[k] = s->mtfa[s->mtfbase[i] + j];
                                    k--;
                                }
                                s->mtfbase[i] = k + 1;
                            }
                        }
                    }
                }
                /*-- end uc = MTF ( nextSym-1 ) --*/

                s->unzftab[s->seqToUnseq[uc]]++;
                if (s->smallDecompress)
                    s->ll16[nblock] = (UInt16)(s->seqToUnseq[uc]);
                else
                    s->tt[nblock] = (UInt32)(s->seqToUnseq[uc]);
                nblock++;

                GET_MTF_VAL(BZ_X_MTF_5, BZ_X_MTF_6, nextSym);
                continue;
            }
        }

        /* Now we know what nblock is, we can do a better sanity
         check on s->origPtr.
      */
        if (s->origPtr < 0 || s->origPtr >= nblock)
            RETURN(BZ_DATA_ERROR);

        /*-- Set up cftab to facilitate generation of T^(-1) --*/
        /* Check: unzftab entries in range. */
        for (i = 0; i <= 255; i++) {
            if (s->unzftab[i] < 0 || s->unzftab[i] > nblock)
                RETURN(BZ_DATA_ERROR);
        }
        /* Actually generate cftab. */
        s->cftab[0] = 0;
        for (i = 1; i <= 256; i++)
            s->cftab[i] = s->unzftab[i - 1];
        for (i = 1; i <= 256; i++)
            s->cftab[i] += s->cftab[i - 1];
        /* Check: cftab entries in range. */
        for (i = 0; i <= 256; i++) {
            if (s->cftab[i] < 0 || s->cftab[i] > nblock) {
                /* s->cftab[i] can legitimately be == nblock */
                RETURN(BZ_DATA_ERROR);
            }
        }
        /* Check: cftab entries non-descending. */
        for (i = 1; i <= 256; i++) {
            if (s->cftab[i - 1] > s->cftab[i]) {
                RETURN(BZ_DATA_ERROR);
            }
        }

        s->state_out_len = 0;
        s->state_out_ch = 0;
        BZ_INITIALISE_CRC(s->calculatedBlockCRC);
        s->state = BZ_X_OUTPUT;
        if (s->verbosity >= 2)
            VPrintf0("rt+rld");

        if (s->smallDecompress) {
            /*-- Make a copy of cftab, used in generation of T --*/
            for (i = 0; i <= 256; i++)
                s->cftabCopy[i] = s->cftab[i];

            /*-- compute the T vector --*/
            for (i = 0; i < nblock; i++) {
                uc = (UChar)(s->ll16[i]);
                SET_LL(i, s->cftabCopy[uc]);
                s->cftabCopy[uc]++;
            }

            /*-- Compute T^(-1) by pointer reversal on T --*/
            i = s->origPtr;
            j = GET_LL(i);
            do {
                Int32 tmp = GET_LL(j);
                SET_LL(j, i);
                i = j;
                j = tmp;
            } while (i != s->origPtr);

            s->tPos = s->origPtr;
            s->nblock_used = 0;
            if (s->blockRandomised) {
                BZ_RAND_INIT_MASK;
                BZ_GET_SMALL(s->k0);
                s->nblock_used++;
                BZ_RAND_UPD_MASK;
                s->k0 ^= BZ_RAND_MASK;
            }
            else {
                BZ_GET_SMALL(s->k0);
                s->nblock_used++;
            }
        }
        else {
            /*-- compute the T^(-1) vector --*/
            for (i = 0; i < nblock; i++) {
                uc = (UChar)(s->tt[i] & 0xff);
                s->tt[s->cftab[uc]] |= (i << 8);
                s->cftab[uc]++;
            }

            s->tPos = s->tt[s->origPtr] >> 8;
            s->nblock_used = 0;
            if (s->blockRandomised) {
                BZ_RAND_INIT_MASK;
                BZ_GET_FAST(s->k0);
                s->nblock_used++;
                BZ_RAND_UPD_MASK;
                s->k0 ^= BZ_RAND_MASK;
            }
            else {
                BZ_GET_FAST(s->k0);
                s->nblock_used++;
            }
        }

        RETURN(BZ_OK);

    endhdr_2:

        GET_UCHAR(BZ_X_ENDHDR_2, uc);
        if (uc != 0x72)
            RETURN(BZ_DATA_ERROR);
        GET_UCHAR(BZ_X_ENDHDR_3, uc);
        if (uc != 0x45)
            RETURN(BZ_DATA_ERROR);
        GET_UCHAR(BZ_X_ENDHDR_4, uc);
        if (uc != 0x38)
            RETURN(BZ_DATA_ERROR);
        GET_UCHAR(BZ_X_ENDHDR_5, uc);
        if (uc != 0x50)
            RETURN(BZ_DATA_ERROR);
        GET_UCHAR(BZ_X_ENDHDR_6, uc);
        if (uc != 0x90)
            RETURN(BZ_DATA_ERROR);

        s->storedCombinedCRC = 0;
        GET_UCHAR(BZ_X_CCRC_1, uc);
        s->storedCombinedCRC = (s->storedCombinedCRC << 8) | ((UInt32)uc);
        GET_UCHAR(BZ_X_CCRC_2, uc);
        s->storedCombinedCRC = (s->storedCombinedCRC << 8) | ((UInt32)uc);
        GET_UCHAR(BZ_X_CCRC_3, uc);
        s->storedCombinedCRC = (s->storedCombinedCRC << 8) | ((UInt32)uc);
        GET_UCHAR(BZ_X_CCRC_4, uc);
        s->storedCombinedCRC = (s->storedCombinedCRC << 8) | ((UInt32)uc);

        s->state = BZ_X_IDLE;
        RETURN(BZ_STREAM_END);

        default: AssertH(False, 4001);
    }

    AssertH(False, 4002);

save_state_and_return:

    s->save_i = i;
    s->save_j = j;
    s->save_t = t;
    s->save_alphaSize = alphaSize;
    s->save_nGroups = nGroups;
    s->save_nSelectors = nSelectors;
    s->save_EOB = EOB;
    s->save_groupNo = groupNo;
    s->save_groupPos = groupPos;
    s->save_nextSym = nextSym;
    s->save_nblockMAX = nblockMAX;
    s->save_nblock = nblock;
    s->save_es = es;
    s->save_N = N;
    s->save_curr = curr;
    s->save_zt = zt;
    s->save_zn = zn;
    s->save_zvec = zvec;
    s->save_zj = zj;
    s->save_gSel = gSel;
    s->save_gMinlen = gMinlen;
    s->save_gLimit = gLimit;
    s->save_gBase = gBase;
    s->save_gPerm = gPerm;

    return retVal;
}

/*-------------------------------------------------------------*/
/*--- end                                      decompress.c ---*/
/*-------------------------------------------------------------*/
