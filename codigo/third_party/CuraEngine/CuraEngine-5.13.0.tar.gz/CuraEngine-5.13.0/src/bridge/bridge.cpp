// Copyright (c) 2025 Ultimaker B.V.
// CuraEngine is released under the terms of the AGPLv3 or higher.

#include "bridge/bridge.h"

#include <range/v3/action/stable_sort.hpp>
#include <range/v3/algorithm/reverse.hpp>

#include "LayerPlan.h"
#include "PathAdapter.h"
#include "bridge/ExpansionRange.h"
#include "bridge/SegmentOverlapping.h"
#include "bridge/TransformedShape.h"
#include "geometry/PointMatrix.h"
#include "geometry/Polygon.h"
#include "settings/EnumSettings.h"
#include "settings/types/Ratio.h"
#include "sliceDataStorage.h"
#include "utils/AABB.h"
#include "utils/linearAlg2D.h"
#include "utils/math.h"
#include "utils/types/geometry.h"


namespace cura
{

/*!
 * Calculates all the intersections between a horizontal line and the given transformed shape
 * @param line_y The horizontal line Y coordinate
 * @param transformed_shape The shape to intersect with
 * @return The list of X coordinates of the intersections, unsorted
 */
std::vector<coord_t> shapeLineIntersections(const coord_t line_y, const TransformedShape& transformed_shape)
{
    std::vector<coord_t> intersections;

    for (const TransformedSegment& transformed_segment : transformed_shape.getSegments())
    {
        if (transformed_segment.minY() > line_y || transformed_segment.maxY() < line_y)
        {
            // Segment is fully over or under the line, skip
            continue;
        }

        const std::optional<coord_t> intersection = LinearAlg2D::lineHorizontalLineIntersection(transformed_segment.getStart(), transformed_segment.getEnd(), line_y);
        if (intersection.has_value())
        {
            intersections.push_back(intersection.value());
        }
    }

    return intersections;
}

/*!
 * Evaluates a potential bridging line to see if it can actually bridge between two supported regions
 * @param line_y The Y coordinate of the horizontal line
 * @param transformed_skin_area The skin outline, transformed so that the bridging line is horizontal
 * @param transformed_supported_area The supported regions, transformed so that the bridging line is horizontal
 * @return The score of the line regarding bridging, which can be positive if it is mostly bridging, or negative if it is mostly hanging
 *
 * The score is based on the following criteria:
 *   - Properly bridging segments, i.e. between two supported areas, add their length to the score
 *   - Hanging segments, i.e. supported on one side but not the other (or not at all), subtract their length from the score
 *   - Segments that lie on a supported area substract part of their length from the score  */
coord_t evaluateBridgeLine(const coord_t line_y, const TransformedShape& transformed_skin_area, const TransformedShape& transformed_supported_area)
{
    // Calculate intersections with skin outline to see which segments should actually be printed
    std::vector<coord_t> skin_outline_intersections = shapeLineIntersections(line_y, transformed_skin_area);
    if (skin_outline_intersections.size() < 2)
    {
        // We need to enter the skin at some point to bridge inside
        return 0;
    }
    ranges::stable_sort(skin_outline_intersections);

    // Calculate intersections with supported regions to see which segments are anchored
    std::vector<coord_t> supported_regions_intersections = shapeLineIntersections(line_y, transformed_supported_area);
    ranges::stable_sort(supported_regions_intersections);

    enum class BridgeStatus
    {
        Outside, // Segment is outside the skin
        Hanging, // Segment has started to extrude over air
        Anchored, // Segment has been anchored to a supported area
        Supported, // Segment is being extruded over a supported area
    };

    // Loop through intersections with skin and supported regions to see which parts of the line are hanging/bridging/supported
    bool inside_skin_area = false;
    bool inside_supported_area = false;
    coord_t last_position;
    coord_t segment_score = 0;
    BridgeStatus bridge_status = BridgeStatus::Outside;
    while (! skin_outline_intersections.empty() || ! supported_regions_intersections.empty())
    {
        // See what is the next intersection: skin, supported or both
        bool next_intersection_is_skin_area = false;
        bool next_intersection_is_supported_area = false;
        if (skin_outline_intersections.empty())
        {
            next_intersection_is_supported_area = true;
        }
        else if (supported_regions_intersections.empty())
        {
            next_intersection_is_skin_area = true;
        }
        else
        {
            const double next_intersection_skin_area = skin_outline_intersections.front();
            const double next_intersection_supported_area = supported_regions_intersections.front();

            if (is_zero(next_intersection_skin_area - next_intersection_supported_area))
            {
                next_intersection_is_skin_area = true;
                next_intersection_is_supported_area = true;
            }
            else if (next_intersection_skin_area <= next_intersection_supported_area)
            {
                next_intersection_is_skin_area = true;
                if (inside_skin_area && inside_supported_area)
                {
                    // When leaving skin, assume also leaving supported. This should always happen naturally, but may not due to rounding errors.
                    next_intersection_is_supported_area = true;
                }
            }
            else
            {
                next_intersection_is_supported_area = true;
                if (! inside_supported_area && ! inside_skin_area)
                {
                    // When reaching supported, assume also reaching skin. This should always happen naturally, but may not due to rounding errors.
                    next_intersection_is_skin_area = true;
                }
            }
        }

        // Get new insideness states
        bool next_inside_skin_area = inside_skin_area;
        bool next_inside_supported_area = inside_supported_area;
        coord_t next_intersection;
        if (next_intersection_is_skin_area)
        {
            next_intersection = skin_outline_intersections.front();
            skin_outline_intersections.erase(skin_outline_intersections.begin());
            next_inside_skin_area = ! next_inside_skin_area;
        }
        if (next_intersection_is_supported_area)
        {
            next_intersection = supported_regions_intersections.front();
            supported_regions_intersections.erase(supported_regions_intersections.begin());
            next_inside_supported_area = ! next_inside_supported_area;
        }

        const bool leaving_skin = next_intersection_is_skin_area && ! next_inside_skin_area;
        const bool reaching_supported = next_intersection_is_supported_area && next_inside_supported_area;
        double add_segment_score_weight = 0.0;

        switch (bridge_status)
        {
        case BridgeStatus::Outside:
            bridge_status = reaching_supported ? BridgeStatus::Supported : BridgeStatus::Hanging;
            break;

        case BridgeStatus::Supported:
            bridge_status = leaving_skin ? BridgeStatus::Outside : BridgeStatus::Anchored;
            // Negatively account for fully supported lines to avoid lonely line parts over the supported areas
            add_segment_score_weight = -0.1;
            break;

        case BridgeStatus::Hanging:
            add_segment_score_weight = -1.0;
            bridge_status = reaching_supported ? BridgeStatus::Supported : BridgeStatus::Outside;
            break;

        case BridgeStatus::Anchored:
            if (reaching_supported)
            {
                add_segment_score_weight = 1.0;
                bridge_status = BridgeStatus::Supported;
            }
            else if (leaving_skin)
            {
                add_segment_score_weight = -1.0;
                bridge_status = BridgeStatus::Outside;
            }
            break;
        }

        if (add_segment_score_weight != 0.0)
        {
            const coord_t segment_length = next_intersection - last_position;
            segment_score += std::llrint(segment_length * add_segment_score_weight);
        }

        last_position = next_intersection;
        inside_skin_area = next_inside_skin_area;
        inside_supported_area = next_inside_supported_area;
    }

    return segment_score;
}

/*!
 * Evaluate the bridging lines scoring for the given angle
 * @param skin_outline The skin outline to be filled
 * @param supported_regions The supported regions areas
 * @param line_width The bridging line width
 * @param angle The current angle to be tested
 * @return The global bridging score for this angle */
coord_t evaluateBridgeLines(const Shape& skin_outline, const Shape& supported_regions, const coord_t line_width, const AngleDegrees& angle)
{
    // Transform the skin outline and supported regions according to the angle to speedup intersections calculations
    const PointMatrix matrix(angle);
    const TransformedShape transformed_skin_area(skin_outline, matrix);
    const TransformedShape transformed_supported_area(supported_regions, matrix);

    if (transformed_skin_area.minY() >= transformed_skin_area.maxY() || transformed_supported_area.minY() >= transformed_supported_area.maxY())
    {
        return std::numeric_limits<coord_t>::lowest();
    }

    const size_t bridge_lines_count = (transformed_skin_area.maxY() - transformed_skin_area.minY()) / line_width;
    if (bridge_lines_count == 0)
    {
        // We cannot fit a single line in this direction, give up
        return std::numeric_limits<coord_t>::lowest();
    }

    const coord_t line_min = transformed_skin_area.minY() + line_width * 0.5;

    // Evaluated lines that could be properly bridging
    coord_t line_score = 0;
    const TransformedShape empty_transformed_shape;
    for (size_t i = 0; i < bridge_lines_count; ++i)
    {
        const coord_t line_y = line_min + i * line_width;
        const bool has_supports = line_y >= transformed_supported_area.minY() && line_y <= transformed_supported_area.maxY();
        line_score += evaluateBridgeLine(line_y, transformed_skin_area, has_supports ? transformed_supported_area : empty_transformed_shape);
    }

    return line_score;
}

/*!
 * Gets the proper angle when bridging over infill
 * @param mesh The mesh being processed, which contains the actual infill angles
 * @param layer_nr The number of the layer being processed
 * @return The angle to be applied to bridging over infill on this layer
 */
AngleDegrees bridgeOverInfillAngle(const SliceMeshStorage& mesh, const unsigned layer_nr)
{
    if (layer_nr == 0)
    {
        // Obviously there is no infill below
        return 0;
    }

    const std::vector<AngleDegrees>& infill_angles = mesh.infill_angles;
    assert(! infill_angles.empty());

    const AngleDegrees infill_angle_below = infill_angles[(layer_nr - 1) % infill_angles.size()];
    const auto infill_pattern = mesh.settings.get<EFillMethod>("infill_pattern");

    AngleDegrees bridge_angle;

    switch (infill_pattern)
    {
    case EFillMethod::CROSS:
    case EFillMethod::CROSS_3D:
        bridge_angle = 22.5;
        break;
    case EFillMethod::GYROID:
    case EFillMethod::CONCENTRIC:
    case EFillMethod::LIGHTNING:
    case EFillMethod::PLUGIN:
    case EFillMethod::NONE:
        bridge_angle = 45;
        break;
    case EFillMethod::CUBICSUBDIV:
        bridge_angle = infill_angle_below + 45;
        break;
    case EFillMethod::TRIANGLES:
    case EFillMethod::LINES:
    case EFillMethod::TRIHEXAGON:
    case EFillMethod::CUBIC:
    case EFillMethod::ZIG_ZAG:
    case EFillMethod::HONEYCOMB:
    case EFillMethod::OCTAGON:
        bridge_angle = infill_angle_below + 90;
        break;
    case EFillMethod::QUARTER_CUBIC:
    case EFillMethod::TETRAHEDRAL:
    case EFillMethod::GRID:
        bridge_angle = infill_angle_below;
        break;
    }

    return bridge_angle;
}

std::optional<AngleDegrees> bridgeAngle(
    const SliceMeshStorage& mesh,
    const Shape& skin_outline,
    const SliceDataStorage& storage,
    const unsigned layer_nr,
    const unsigned bridge_layer,
    const SupportLayer* support_layer,
    Shape& supported_regions)
{
    const Settings& settings = mesh.settings;
    const bool bridge_settings_enabled = settings.get<bool>("bridge_settings_enabled");
    if (! bridge_settings_enabled)
    {
        return std::nullopt;
    }

    AABB boundary_box(skin_outline);

    const coord_t line_width = settings.get<coord_t>("skin_line_width");

    // To detect if we have a bridge, first calculate the intersection of the current layer with the previous layer.
    //  This gives us the islands that the layer rests on.
    Shape islands;

    Shape prev_layer_outline; // we also want the complete outline of the previous layer
    Shape prev_layer_infill;

    // include parts from all meshes
    for (const std::shared_ptr<SliceMeshStorage>& mesh_ptr : storage.meshes)
    {
        const auto& mesh = *mesh_ptr;
        if (mesh.isPrinted())
        {
            const coord_t infill_line_distance = mesh.settings.get<coord_t>("infill_line_distance");
            const bool part_has_sparse_infill = infill_line_distance == 0;

            for (const SliceLayerPart& prev_layer_part : mesh.layers[layer_nr - bridge_layer].parts)
            {
                Shape prev_layer_part_infill = prev_layer_part.getOwnInfillArea();
                prev_layer_infill = prev_layer_infill.unionPolygons(prev_layer_part_infill);

                Shape solid_below(prev_layer_part.outline);
                if (bridge_layer == 1 && part_has_sparse_infill)
                {
                    solid_below = solid_below.difference(prev_layer_part_infill);
                }
                prev_layer_outline.push_back(solid_below); // not intersected with skin

                if (! boundary_box.hit(prev_layer_part.boundaryBox))
                    continue;

                islands.push_back(skin_outline.intersection(solid_below));
            }
        }
    }
    supported_regions = islands;

    if (support_layer)
    {
        // add the regions of the skin that have support below them to supportedRegions
        // but don't add these regions to islands because that can actually cause the code
        // below to consider the skin a bridge when it isn't (e.g. a skin that is supported by
        // the model on one side but the remainder of the skin is above support would look like
        // a bridge because it would have two islands) - FIXME more work required here?

        if (! support_layer->support_roof.empty())
        {
            AABB support_roof_bb(support_layer->support_roof);
            if (boundary_box.hit(support_roof_bb))
            {
                prev_layer_outline.push_back(support_layer->support_roof); // not intersected with skin

                Shape supported_skin(skin_outline.intersection(support_layer->support_roof));
                if (! supported_skin.empty())
                {
                    supported_regions.push_back(supported_skin);
                }
            }
        }
        else
        {
            for (const SupportInfillPart& support_part : support_layer->support_infill_parts)
            {
                AABB support_part_bb(support_part.getInfillArea());
                if (boundary_box.hit(support_part_bb))
                {
                    prev_layer_outline.push_back(support_part.getInfillArea()); // not intersected with skin

                    Shape supported_skin(skin_outline.intersection(support_part.getInfillArea()));
                    if (! supported_skin.empty())
                    {
                        supported_regions.push_back(supported_skin);
                    }
                }
            }
        }
    }

    const Ratio support_threshold = settings.get<Ratio>("bridge_skin_support_threshold");
    if (support_threshold == 0 || (supported_regions.area() / (skin_outline.area() + 1)) >= support_threshold)
    {
        // as the proportion of the skin region that is supported is >= supportThreshold, it's not
        // considered to be a bridge and the original bridge detection code below is skipped
        return std::nullopt;
    }

    prev_layer_infill = skin_outline.intersection(prev_layer_infill);
    const Ratio infill_ratio = prev_layer_infill.area() / (skin_outline.area() + 1);
    if (infill_ratio > 0.5) // In practice, the ratio should always be close to 0 or 1, so 0.5 should be good enough
    {
        // We are doing bridging over infill, so use the infill angle instead of trying to calculate a proper angle
        return bridgeOverInfillAngle(mesh, layer_nr);
    }

    struct FitAngle
    {
        coord_t score;
        std::optional<AngleDegrees> angle;
    };

    OpenLinesSet bridge_area_lines;
    for (auto& path : skin_outline)
    {
        bridge_area_lines.push_back(path.toPseudoOpenPolyline());
    }
    bridge_area_lines = bridge_area_lines.difference(supported_regions.offset(10));

    if (bridge_area_lines.empty())
    {
        // if bridge lines are supported in all directions, use the following heuristic
        // 1. calculate the minimum oriented bounding box
        // 2. bridge lines in the smallest axis of this min oriented
        //    bounding box is considered the best orientation
        // This heuristic is used since this produces more consistent bridging angles.
        // While the else-case would produce a better theoretical bridging angle it would
        // produce a different angle for similar areas within the same print. Since this
        // would look _chaotic_ on the final print a more consistent approach is used.
        auto skin_outline_ = skin_outline;
        skin_outline_.makeConvex();
        auto [aabb, angle] = AABB::minimumAreaOrientedBoundingBox(skin_outline_);
        if (aabb.height() > aabb.width())
        {
            angle += AngleDegrees(90);
        }
        return -AngleDegrees(angle);
    }

    FitAngle best_angle{ std::numeric_limits<coord_t>::lowest(), std::nullopt };
    for (AngleDegrees angle = 0; angle < 180; angle += 1)
    {
        const coord_t score = evaluateBridgeLines(skin_outline, supported_regions, line_width, angle);
        if (score > best_angle.score)
        {
            best_angle = { score, angle + 90 };
        }
    }

    return best_angle.angle;
}
/*!
 * Make the expanded ranges for the given segment
 * @param segment The segment to be expanded
 * @param infill_lines_below The infill lines on the layer below that we can expand the segment to
 * @param expand_direction The expand direction, 1 means expand to the right, -1 expand to the left
 * @return The list of new expansion ranges, bottom to top, which covers the same vertical range as the segment
 */
std::vector<ExpansionRange> makeExpandedRanges(const TransformedSegment& segment, const std::vector<TransformedSegment>& infill_lines_below, const int8_t expand_direction)
{
    // List of expansion ranges, initiall filled with a single non-expanded range
    std::vector<ExpansionRange> expanded_ranges;
    expanded_ranges.push_back(ExpansionRange(segment.minY(), segment.maxY(), &segment));

    if (! expanded_ranges.front().isValid())
    {
        // Do not try to expand horizontal segments
        return expanded_ranges;
    }

    // Now loop on every infill line and update the expansion ranges accordingly
    for (const TransformedSegment& infill_line_below : infill_lines_below)
    {
        // First calculate the overlapping of the infill line with the segment in the expand direction, so that we get only lines that (fully or partially) are on the expansion
        // side of the segment
        const std::optional<SegmentOverlapping> overlapping = segment.calculateOverlapping(infill_line_below, expand_direction);
        if (! overlapping.has_value())
        {
            continue;
        }

        // The line does overlap the expansion area of the segment, now checks whether it overlaps with the current ranges
        const TransformedSegment& line_part = overlapping->other_overlapping_part;

        // The new list of expanded ranges being build
        std::vector<ExpansionRange> new_expanded_ranges;

        // The current expansion range being created, which can spread over multiple actual ranges
        std::optional<ExpansionRange> replacing_range;

        // Helper function to finalize and store the replacement range
        const auto commit_replacing_range = [&replacing_range, &new_expanded_ranges]()
        {
            if (replacing_range.has_value())
            {
                if (replacing_range->isValid())
                {
                    new_expanded_ranges.push_back(*replacing_range);
                }
                replacing_range.reset();
            }
        };

        for (const ExpansionRange& expanded_range : expanded_ranges)
        {
            // See if the line overlaps, but this time in reverse expand direction because we want those who are as close as possible to the initial segment
            const std::optional<SegmentOverlapping> range_overlapping = expanded_range.calculateOverlapping(line_part, -expand_direction);
            if (! range_overlapping.has_value())
            {
                commit_replacing_range();
                new_expanded_ranges.push_back(std::move(expanded_range));
                continue;
            }

            if (range_overlapping->type != SegmentOverlappingType::Bottom && range_overlapping->type != SegmentOverlappingType::Full)
            {
                // The line overlaps, but not on the bottom part of the range, so keep the current range but crop its top part
                commit_replacing_range();

                ExpansionRange cropped_range_bottom = std::move(expanded_range);
                cropped_range_bottom.cropTop(range_overlapping->other_overlapping_part.minY());
                if (cropped_range_bottom.isValid())
                {
                    new_expanded_ranges.push_back(std::move(cropped_range_bottom));
                }
            }

            if (! replacing_range.has_value())
            {
                // We don't have a replacing range yet, so since we are overlapping, create a new one starting a the current overlapping line start position
                replacing_range = ExpansionRange(range_overlapping->other_overlapping_part, &infill_line_below);
            }
            else
            {
                // We have a replacing range, update it so that it now ends at the same position as the overlapping line end
                replacing_range->setProjectedEnd(range_overlapping->other_overlapping_part.getEnd());
            }

            if (range_overlapping->type != SegmentOverlappingType::Top && range_overlapping->type != SegmentOverlappingType::Full)
            {
                // The line overlaps, but not on the top part of the range, so keep the current range but crop its bottom
                commit_replacing_range();

                ExpansionRange cropped_range_top = std::move(expanded_range);
                cropped_range_top.cropBottom(range_overlapping->other_overlapping_part.maxY());
                if (cropped_range_top.isValid())
                {
                    new_expanded_ranges.push_back(std::move(cropped_range_top));
                }
            }
        }

        commit_replacing_range();

        if (! new_expanded_ranges.empty())
        {
            expanded_ranges = std::move(new_expanded_ranges);
        }
    }

    return expanded_ranges;
}

/*!
 * Update the expanded polygon area according to the given expansion ranges
 * @param segment The segment being expanded
 * @param expanded_ranges The expansion ranges calculated for the segment
 * @param expand_direction The expand direction, 1 means expand to the right, -1 expand to the left
 * @param expanded_polygon The expanded polygon to add the points to
 * @param current_supporting_infill_line The infill line below currently supporting the bridging, which will be updated over iterations when necessary
 */
void updateExpandedPolygon(
    const TransformedSegment& segment,
    const std::vector<ExpansionRange>& expanded_ranges,
    const int8_t expand_direction,
    Polygon& expanded_polygon,
    const TransformedSegment*& current_supporting_infill_line)
{
    for (const ExpansionRange& expanded_range : expanded_ranges)
    {
        if (expanded_range.getSupportingSegment() == current_supporting_infill_line)
        {
            // As long as we have the same supporting infill line, don't have points because we just move along the same line
            continue;
        }

        if (current_supporting_infill_line == nullptr)
        {
            // This is the first iteration for this polygon, add the initial point
            if (! expanded_range.isProjected())
            {
                // This is an unitialized range, use the raw segment
                expanded_polygon.push_back(segment.getStart());
            }
            else
            {
                expanded_polygon.push_back(expand_direction > 0 ? expanded_range.getProjectedSegment().getStart() : expanded_range.getProjectedSegment().getEnd());
            }
        }
        else
        {
            Point2LL next_start_position;

            if (! expanded_range.isProjected())
            {
                // This is an unprojected range, use the raw segment
                const coord_t position_switch_y = expand_direction > 0 ? expanded_range.minY() : expanded_range.maxY();
                next_start_position = Point2LL(LinearAlg2D::lineHorizontalLineIntersection(segment.getStart(), segment.getEnd(), position_switch_y).value_or(0), position_switch_y);
            }
            else
            {
                next_start_position = expand_direction > 0 ? expanded_range.getProjectedSegment().getStart() : expanded_range.getProjectedSegment().getEnd();
            }

            // Add point to close anchoring to previous infill line
            expanded_polygon.pushBackIfFormingSegment(Point2LL(
                LinearAlg2D::lineHorizontalLineIntersection(current_supporting_infill_line->getStart(), current_supporting_infill_line->getEnd(), next_start_position.Y)
                    .value_or(0),
                next_start_position.Y));

            // Add point to start anchoring on new infill line
            expanded_polygon.pushBackIfFormingSegment(next_start_position);
        }

        current_supporting_infill_line = expanded_range.getSupportingSegment();
    }
}

/*!
 * Expands a segment of a polygon so that bridging will always have supporting infill lines below for proper anchoring
 * @param segment The current segment to be expanded
 * @param infill_lines_below The infill lines on the layer below
 * @param expanded_polygon The resulting expanded polygon
 * @param current_supporting_infill_line The infill line below currently supporting the bridging, which will be updated over iterations when necessary
 *
 * Before reading this explanation, see image in doc/bridging_skin_support.svg
 * The expansion works by initially assigning an infinite range on the left (or right) of a segment, you can imagine a horizontal band starting from the segment. Then for each
 * infill line, we check whether it crosses this range. When it is the case, we update the range so that the horizontal band is now divided in multiple parts, each of them
 * being supported (or not) by an infill line. Then we do it again for the next infill line, which will update the ranges until we have the infill lines that are the closer to
 * the segment.
 */
void expandSegment(
    const TransformedSegment& segment,
    const std::vector<TransformedSegment>& infill_lines_below,
    Polygon& expanded_polygon,
    const TransformedSegment*& current_supporting_infill_line)
{
    // 1 means expand to the right, -1 expand to the left
    const int8_t expand_direction = sign(segment.getEnd().Y - segment.getStart().Y);

    // Make the list of expanded ranges for this segment
    std::vector<ExpansionRange> expanded_ranges = makeExpandedRanges(segment, infill_lines_below, expand_direction);

    if (expand_direction < 0)
    {
        ranges::reverse(expanded_ranges);
    }

    // Now we have the final expansion ranges, update the expanded polygon according. We add points only when the current supporting line is changing, so that the polygon is
    // as compact as possible.
    updateExpandedPolygon(segment, expanded_ranges, expand_direction, expanded_polygon, current_supporting_infill_line);
}

std::tuple<Shape, AngleDegrees> makeBridgeOverInfillPrintable(
    const Shape& infill_contour,
    const Shape& infill_below_skin_area,
    const SliceMeshStorage& mesh,
    const LayerPlan* completed_layer_plan_below,
    const unsigned layer_nr)
{
    if (layer_nr == 0 || infill_below_skin_area.empty())
    {
        return {};
    }

    Shape unsupported_infill_below_skin_area = infill_below_skin_area;
    for (const SliceLayerPart& part_below : mesh.layers[layer_nr - 1].parts)
    {
        for (const SkinPart& skin_part_below : part_below.skin_parts)
        {
            // Ignore areas that actually have skin below, we can't bridge over them
            unsupported_infill_below_skin_area = unsupported_infill_below_skin_area.difference(skin_part_below.outline);
        }
    }

    if (unsupported_infill_below_skin_area.empty())
    {
        return {};
    }

    // Calculate the proper bridging angle, according to the type of infill below
    const AngleDegrees bridge_angle = bridgeOverInfillAngle(mesh, layer_nr);

    // We will expand the bridging area following the lines direction
    const AngleDegrees expansion_angle = bridge_angle + 90;
    const MixedLinesSet infill_lines_below = completed_layer_plan_below->getGeneratedInfillLines(&mesh);

    // Rotate all the infill lines below so that they are in a space where the under skin area should be expanded horizontally
    const PointMatrix matrix(expansion_angle);
    TransformedShape filtered_infill_lines_below(matrix);

    constexpr bool filter_out_horizontal = true;
    for (const PolylinePtr& infill_line_below : infill_lines_below)
    {
        for (auto iterator = infill_line_below->cbeginSegments(); iterator != infill_line_below->cendSegments(); ++iterator)
        {
            filtered_infill_lines_below.addSegment((*iterator).start, (*iterator).end, filter_out_horizontal);
        }
    }

    filtered_infill_lines_below.addShape(infill_contour, filter_out_horizontal);

    // Now expand each polygon by expanding its segments horizontally according to the supporting infill lines
    Shape transformed_expanded_infill_below_skin_area;
    for (const Polygon& infill_below_skin_polygon : unsupported_infill_below_skin_area)
    {
        const TransformedShape transformed_infill_below_skin_polygon(infill_below_skin_polygon, matrix);

        Polygon expanded_polygon;
        const TransformedSegment* current_supporting_infill_line = nullptr;
        for (const TransformedSegment& transformed_infill_below_skin_segment : transformed_infill_below_skin_polygon.getSegments())
        {
            expandSegment(transformed_infill_below_skin_segment, filtered_infill_lines_below.getSegments(), expanded_polygon, current_supporting_infill_line);
        }
        transformed_expanded_infill_below_skin_area.push_back(std::move(expanded_polygon));
    }

    // Move output polygons back to original transform
    transformed_expanded_infill_below_skin_area.applyMatrix(matrix.inverse());

    // Perform a morphological closing to remove overlapping lines
    transformed_expanded_infill_below_skin_area = transformed_expanded_infill_below_skin_area.offset(EPSILON).offset(-EPSILON).intersection(infill_contour);

    return { transformed_expanded_infill_below_skin_area, bridge_angle };
}

/*!
 * Calculates whether the given tip of an extrusion segment is properly anchored for bridging
 * @param bridge_mask The bridging mask, i.e. the regions that are fully over air
 * @param wall The wall line being printed
 * @param tip_index The index of the tip to be considered
 * @param tip The position of the tip to be considered
 * @param other_tip The position of the opposite tip of the segment
 * @param tip_inside_bridge_mask Indicates whether the tip is inside the bridge mask
 * @param segment_direction Indicates whether the segment goes forwards on the extrusion line (1) or backwards (-1)
 * @param min_anchoring_length The minimum anchoring length to be reached to consider that the segment is properly anchored
 * @param intersections The intersections of the segment with the bridge mask (ordered in original segment orientation)
 * @return True if the tip is properly anchored, false if it is fully hanging
 */
bool isWallTipAnchored(
    const Shape& bridge_mask,
    const PathAdapter<ExtrusionLine>& wall,
    const size_t tip_index,
    const Point2LL& tip,
    const Point2LL& other_tip,
    const bool tip_inside_bridge_mask,
    const std::ptrdiff_t segment_direction,
    const coord_t min_anchoring_length,
    const std::vector<float>& intersections)
{
    coord_t remaining_anchoring_length = min_anchoring_length;

    if (! tip_inside_bridge_mask)
    {
        // The tip of the segment is supported, so check that the total anchored length is long enough to provide a proper anchoring
        const float closest_intersection = segment_direction > 0 ? intersections.front() : (1.0 - intersections.back());
        const coord_t segment_length = vSize(other_tip - tip);
        const coord_t inside_anchoring_length = closest_intersection * segment_length;
        remaining_anchoring_length -= inside_anchoring_length;
    }

    if (remaining_anchoring_length > 0)
    {
        // The inside of the segment is not enough to anchor it properly, take a look on the following segments
        const coord_t max_outside_search_length = min_anchoring_length * 2;
        coord_t remaining_search_length = max_outside_search_length;

        bool over_air = tip_inside_bridge_mask;
        Point2LL following_segment_p0 = tip;
        ptrdiff_t next_point_index = tip_index;

        const auto increment_index = [&next_point_index, segment_direction, &wall]()
        {
            next_point_index = ((next_point_index - segment_direction) + wall.size()) % wall.size();
        };

        const auto account_for_segment = [&over_air, &remaining_anchoring_length, &remaining_search_length](const Point2LL& start, const Point2LL& end)
        {
            const coord_t segment_length = vSize(end - start);
            if (! over_air)
            {
                remaining_anchoring_length -= std::min(remaining_search_length, segment_length);
            }
            remaining_search_length = std::max(static_cast<coord_t>(0), remaining_search_length - segment_length);
        };

        increment_index();
        while (remaining_search_length > 0 && remaining_anchoring_length > 0)
        {
            // for each following segment, account for parts of the segments that are not over air, i.e. not inside the bridging area
            const Point2LL following_segment_p1 = wall.pointAt(next_point_index);
            std::vector<float> following_segment_intersections = bridge_mask.intersectionsWithSegment(following_segment_p0, following_segment_p1);

            Point2LL current_position = following_segment_p0;

            ranges::stable_sort(following_segment_intersections);
            for (const float next_intersection : following_segment_intersections)
            {
                const Point2LL next_intersection_position = lerp(following_segment_p0, following_segment_p1, next_intersection);
                account_for_segment(current_position, next_intersection_position);

                over_air = ! over_air; // Since we have intersected the bridging area, this flips
                current_position = next_intersection_position;
            }

            account_for_segment(current_position, following_segment_p1);

            following_segment_p0 = following_segment_p1;
            increment_index();
        }
    }

    // The tip is anchored if somehow we found enough adjacent segments that are supported
    return remaining_anchoring_length <= 0;
}

std::vector<std::tuple<Ratio, Ratio>> wallSegmentUsesBridging(
    const AABB& bridge_mask_bb,
    const Shape& bridge_mask,
    const PathAdapter<ExtrusionLine>& wall,
    const size_t segment_index,
    const Ratio& segment_start_ratio,
    const Ratio& segment_end_ratio,
    const coord_t min_bridge_line_len,
    const coord_t line_width)
{
    const size_t p0_index = segment_index;
    const size_t p1_index = (segment_index + 1) % wall.size();
    const Point2LL& p0 = wall.pointAt(p0_index);
    const Point2LL& p1 = wall.pointAt(p1_index);
    const coord_t segment_length = vSize(p0 - p1);

    if (! bridge_mask_bb.hit(AABB({ p0, p1 })) || segment_length < min_bridge_line_len)
    {
        // Early out: completely outside bridging area or too small segment
        return {};
    }

    const bool p0_inside_mask = bridge_mask.inside(p0);
    const bool p1_inside_mask = bridge_mask.inside(p1);
    std::vector<float> intersections = bridge_mask.intersectionsWithSegment(p0, p1);

    if (! p0_inside_mask && ! p1_inside_mask && intersections.empty())
    {
        // Not starting nor ending in bridging area, and not crossing it, so obviously not bridging
        return {};
    }

    // In order to properly bridge, the segment needs to be supported at both its tips to get a proper anchoring
    const coord_t min_anchoring_length = line_width;
    ranges::stable_sort(intersections);
    if (! isWallTipAnchored(bridge_mask, wall, p0_index, p0, p1, p0_inside_mask, 1, min_anchoring_length, intersections)
        || ! isWallTipAnchored(bridge_mask, wall, p1_index, p1, p0, p1_inside_mask, -1, min_anchoring_length, intersections))
    {
        // At least one of the tips is not properly anchored, do not bridge the segment
        return {};
    }

    // Loop through all the intersections, starting with the first anchoring subsegment, then switch bridging/non-bridging at each intersection
    Ratio current_position = 0.0;
    bool bridging = p0_inside_mask;
    std::vector<std::tuple<Ratio, Ratio>> bridging_subsegments;
    const auto add_bridging_subsegment
        = [&bridging_subsegments, min_bridge_line_len, segment_length, &segment_start_ratio, &segment_end_ratio](const Ratio& start, const Ratio& end)
    {
        const coord_t bridge_line_len = (end - start) * segment_length;
        if (bridge_line_len >= min_bridge_line_len && end >= segment_start_ratio && start <= segment_end_ratio)
        {
            const Ratio full_segment_start_ratio = std::max(start, segment_start_ratio);
            const Ratio full_segment_end_ratio = std::min(end, segment_end_ratio);

            const Ratio sub_segment_start_ratio = inverse_lerp(segment_start_ratio.value, segment_end_ratio.value, full_segment_start_ratio.value);
            const Ratio sub_segment_end_ratio = inverse_lerp(segment_start_ratio.value, segment_end_ratio.value, full_segment_end_ratio.value);

            bridging_subsegments.push_back(std::make_tuple(sub_segment_start_ratio, sub_segment_end_ratio));
        }
    };

    for (const float next_intersection : intersections)
    {
        if (bridging)
        {
            add_bridging_subsegment(current_position, next_intersection);
        }

        current_position = next_intersection;
        bridging = ! bridging;
    }

    if (bridging)
    {
        add_bridging_subsegment(current_position, 1.0);
    }

    return bridging_subsegments;
}
} // namespace cura
